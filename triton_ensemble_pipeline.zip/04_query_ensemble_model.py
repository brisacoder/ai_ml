import numpy as np
import tritonclient.http as httpclient

client = httpclient.InferenceServerClient(url="localhost:8000")

input_data = np.random.rand(1, 4).astype(np.float32)
inputs = [httpclient.InferInput("input__0", input_data.shape, "FP32")]
inputs[0].set_data_from_numpy(input_data)

outputs = [httpclient.InferRequestedOutput("label")]

response = client.infer(model_name="ensemble", inputs=inputs, outputs=outputs)

label_output = response.as_numpy("label")
print("Input:\n", input_data)
print("Predicted Label:\n", label_output)