import os

model_dir = "models/postprocessor/1"
os.makedirs(model_dir, exist_ok=True)

model_py = """import numpy as np
import triton_python_backend_utils as pb_utils

class TritonPythonModel:
    def initialize(self, args):
        self.labels = ["cat", "dog", "rabbit"]

    def execute(self, requests):
        responses = []
        for request in requests:
            logits_tensor = pb_utils.get_input_tensor_by_name(request, "logits")
            logits = logits_tensor.as_numpy()
            probs = np.exp(logits) / np.sum(np.exp(logits), axis=1, keepdims=True)
            pred_ids = np.argmax(probs, axis=1)
            label_strs = np.array([[self.labels[i]] for i in pred_ids], dtype=object)
            out_tensor = pb_utils.Tensor("label", label_strs)
            responses.append(pb_utils.InferenceResponse(output_tensors=[out_tensor]))
        return responses
"""

with open("models/postprocessor/1/model.py", "w") as f:
    f.write(model_py.strip())

config_text = """name: "postprocessor"
backend: "python"
max_batch_size: 8

input [
  {
    name: "logits"
    data_type: TYPE_FP32
    dims: [3]
  }
]

output [
  {
    name: "label"
    data_type: TYPE_STRING
    dims: [1]
  }
]
"""

with open("models/postprocessor/config.pbtxt", "w") as f:
    f.write(config_text.strip())

print("✅ Postprocessor model and config written.")