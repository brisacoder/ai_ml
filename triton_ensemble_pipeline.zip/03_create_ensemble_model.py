import os

ensemble_dir = "models/ensemble"
os.makedirs(ensemble_dir, exist_ok=True)

config_text = """name: "ensemble"
platform: "ensemble"
max_batch_size: 8

input [
  {
    name: "input__0"
    data_type: TYPE_FP32
    dims: [4]
  }
]

output [
  {
    name: "label"
    data_type: TYPE_STRING
    dims: [1]
  }
]

ensemble_scheduling {
  step [
    {
      model_name: "base_model"
      model_version: -1
      input_map {
        key: "input__0"
        value: "input__0"
      }
      output_map {
        key: "logits"
        value: "logits"
      }
    },
    {
      model_name: "postprocessor"
      model_version: -1
      input_map {
        key: "logits"
        value: "logits"
      }
      output_map {
        key: "label"
        value: "label"
      }
    }
  ]
}
"""

with open(os.path.join(ensemble_dir, "config.pbtxt"), "w") as f:
    f.write(config_text.strip())

print("✅ Ensemble model config created.")