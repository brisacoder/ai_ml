import torch
import torch.nn as nn
import os

class BaseClassifier(nn.Module):
    def __init__(self):
        super(BaseClassifier, self).__init__()
        self.fc = nn.Linear(4, 3)

    def forward(self, x):
        return self.fc(x)

model = BaseClassifier()
example_input = torch.rand(1, 4)
traced_model = torch.jit.trace(model, example_input)

model_dir = "models/base_model/1"
os.makedirs(model_dir, exist_ok=True)
traced_model.save(f"{model_dir}/model.pt")

config = """name: "base_model"
platform: "pytorch_libtorch"
max_batch_size: 8

input [
  {
    name: "input__0"
    data_type: TYPE_FP32
    dims: [4]
  }
]

output [
  {
    name: "logits"
    data_type: TYPE_FP32
    dims: [3]
  }
]
"""

with open("models/base_model/config.pbtxt", "w") as f:
    f.write(config.strip())

print("✅ Base model and config saved.")